#include "album.h"

void album()
{
	lcd_draw_bmp(0,0,"/album/back.bmp");
	init_font();//打开字库
	
	//初始化链表头
	head = init_list();
	
	//1、进来读取文件，新建链表，恢复数据,打不开的照片不插入链表
	read_data(&head);
	printf("读取数据完成\n");
	
	//2、读取目录，把新的图片(链表中没有)插入链表
	pic_read_dir("/album/pic1");
	
	//3.遍历链表，显示上次最后打开的图片
	lcd_draw_bmp(0,0,"/album/back.bmp");
	show_lastpic();

	while(1)
	{	  		
		show_exit();
		
		if(!is_album_empty()){
			lcd_draw_bmp(0,0,"/album/back.bmp");
			show_empty();
			show_exit();			
		}
		
		int s_x,s_y,e_x,e_y;		
		ts_get_xy(&s_x,&s_y,&e_x,&e_y);
		
		//4.左滑显示下一张图片，右滑显示上一张图片，
		//并更新"最后打开的图片位置"的变量
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (e_x - s_x)>50 && abs(e_y - s_y)<80)		//右滑:从左到右 ：上一张
		{	
			show_prev_next(head->list.prev);						
		}
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (s_x - e_x)>50 && abs(e_y - s_y)<80)	//左滑:从右到左 ：下一张	
		{	
			show_prev_next(head->list.next);			
		}
		//5.上滑删除图片,并显示下一张图片
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (s_y - e_y)>50 && abs(e_x - s_x)<80)	//上滑:从下到上 ：删除照片	
		{	
			del_pic();			
			save(head);				//保存			
		}
		
		//6.点击右上角退出,并保存链表数据到文件
		if(e_x>739 && e_x<799 && e_y>0 && e_y<60){	//右上角退出
			head = move_head();
			save(head);
			free(head);
			head = NULL;
			printf("album exit！\n");
			break;
		}			
	}
	
	close_font();
	return ;
}

bool is_album_empty(void)
{
	PIC_NODE_P head_save = NULL;
	
	head_save = head;	//保存当前结点位置
	head = move_head();
	
	if(!is_empty(head)){
		return false;
	}
	head = head_save;
	return true;
}


// 删除照片
void del_pic(void)
{
	//判空
	if(!is_album_empty())	return ;
	
	//PIC_NODE_P head_del = head;  //保存要删除的结点的信息
	
	show_del();
	show_yes();
	show_no();
	
	while(1)
	{
		int s_x,s_y,e_x,e_y;		
		ts_get_xy(&s_x,&s_y,&e_x,&e_y);
		if(e_x>200 && e_x<300 && e_y>300 && e_y<400)
		{
			printf("是\n");
			char path[500];			
			strcpy(path,head->pic.path);
			
			struct list_head *pos = NULL,*pos_del = NULL;
			PIC_NODE_P p = NULL;
			
			pos_del = &(head->list);
			
			head->pic.last = false;
			pos = head->list.prev;		//指针前移
				
			p = list_entry(pos,PIC_NODE,list);
			p->pic.last = true;
			head = p;
			
			list_del(pos_del);	 //从链表中删除
			
			remove(path);	 //从磁盘中删除
	
			printf("照片删除成功！\n");
			show_prev_next(head->list.next);
			return ;
		}
		if(e_x>500 && e_x<600 && e_y>300 && e_y<400)
		{
			printf("否\n");
			show_prev_next(head->list.next);	//显示下一张图片
			return ;
		}
	}
	return ;
}

void show_prev_next(struct list_head *pos)
{
	//判空
	if(!is_album_empty())	return ;
	
	PIC_NODE_P p = NULL;
	
	head->pic.last = false;		//移动前 当前位置标志位 置假
	//pos = head->list.next;	//指针后移
	//pos = head->list.prev;	//指针前移
	p = list_entry(pos,PIC_NODE,list);//获取下一张图片的数据
	
	//跳过头结点
	head = move_head();				//回到头结点
	if(p == head){
		printf("头结点\n");		
		//pos = head->list.next;	//指针后移
		//pos = head->list.prev;	//指针前移
		p = list_entry(pos,PIC_NODE,list);//获取下一张图片的数据
	}
	
	p->pic.last = true;			//移动后 当前位置标志位 置真
	head = p;
	
	lcd_draw_bmp(0,0,"/album/back.bmp");
	
	lcd_center_draw_bmp(p->pic.path);
	//lcd_draw_pic(p->pic.path);
	
	printf("显示图片pic:%s\n",p->pic.name);
	return;
}

bool show_lastpic()
{
	if(!is_empty(head)) return false;
	
	PIC_NODE_P p = NULL;
	struct list_head *pos = NULL;
	
	p = is_last(&head);//返回找到的节点并移动头结点到当前位置
	if(p){
		printf("图片已找到\n");

		lcd_draw_bmp(0,0,"/album/back.bmp");
		
		lcd_center_draw_bmp(p->pic.path);
		//lcd_draw_pic(p->pic.path);
	
		return true;
	}
	
	//找不到则显示第一张照片
	printf("图片没找到，显示第一张\n");
	pos = head->list.next;
	p = list_entry(pos,PIC_NODE,list);
	p->pic.last = true;
	head = p;
	
	lcd_draw_bmp(0,0,"/album/back.bmp");

	lcd_center_draw_bmp(p->pic.path);
	//lcd_draw_pic(p->pic.path);
	
	return true;
}


void pic_read_dir(char *path)
{
	char curdir[500];
	char file_path[500];
	
    //打开目录
    DIR *dp = opendir(path);
    if(!dp){
        perror("opendir\n");
        return;
    }
	printf("opendir%s\n",path);
	
    //读目录
    struct dirent *drt  = NULL;
    while(drt = readdir(dp))
	{
        //略过.和..
        if(strcmp(drt->d_name,".")==0||strcmp(drt->d_name,"..")==0)
            continue;
		
		strcpy(curdir,path);//保存当前目录路径
		
        //目录
        if(drt->d_type==DT_DIR){
            //printf("[%s]\n",drt->d_name);
			
            //递归处理他的子项,目录的路径 path/drt->d_name
            char buf[100] = {};
            sprintf(buf,"%s/%s",path,drt->d_name);
            pic_read_dir(buf);
        }      
        else{
			sprintf(file_path,"%s/%s",curdir,drt->d_name);
			
			//把名字含有.bmp的新照片插入链表
			if(strstr(drt->d_name,".bmp"))
			{			
				printf("%s have pic：%s\n",curdir,drt->d_name);
				if(!is_exist(head,drt->d_name)){
					printf("%s 不在链表中\n",drt->d_name);
					PIC picture;
					
					strcpy(picture.name,drt->d_name);//256
					
					strcpy(picture.path,file_path);//500
					
					picture.last = false;
	
					PIC_NODE_P new = new_node(&picture);
					printf("新建节点\n");
					
					list_add_tail(&new->list, &head->list);

					printf("插入链表\n");
				}			
			}	
        }
    }
    closedir(dp);
	return ;
}


