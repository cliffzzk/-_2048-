#include "font.h"

void init_font()
{
	//初始化字库
	f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");	
}

void show_exit()
{
	fontSetSize(f,30);
	bitmap *bm  = createBitmapWithInit(50,30,4,getColor(0,255,204,153));//a,b,g,r
	char buf[]  = "退出";
	fontPrint(f,bm,0,0,buf,getColor(0,0,0,255),0);
	show_font_to_lcd(g_pfb_memory,749,0,bm);
}

void show_empty()
{
	fontSetSize(f,100);
	bitmap *bm  = createBitmapWithInit(400,100,4,getColor(0,255,255,255));//a,b,g,r
	char buf[]  = "相册为空";
	fontPrint(f,bm,0,0,buf,getColor(0,0,0,0),0);
	show_font_to_lcd(g_pfb_memory,200,200,bm);
}


void show_del()
{
	fontSetSize(f,80);
	bitmap *bm  = createBitmapWithInit(400,100,4,getColor(0,255,204,153));//a,b,g,r
	char buf[]  = "是否删除照片";
	fontPrint(f,bm,0,0,buf,getColor(0,0,0,0),0);	
	show_font_to_lcd(g_pfb_memory,200,100,bm);
}

void show_yes()
{
	fontSetSize(f,100);
	bitmap *bm  = createBitmapWithInit(100,100,4,getColor(0,255,204,153));//a,b,g,r
	char buf[]  = "是";
	fontPrint(f,bm,0,0,buf,getColor(0,0,0,0),0);	
	show_font_to_lcd(g_pfb_memory,200,300,bm);
}

void show_no()
{
	fontSetSize(f,100);
	bitmap *bm  = createBitmapWithInit(100,100,4,getColor(0,255,204,153));//a,b,g,r
	char buf[]  = "否";
	fontPrint(f,bm,0,0,buf,getColor(0,0,0,0),0);	
	show_font_to_lcd(g_pfb_memory,500,300,bm);
}

void show_pass_num(int x,int y,char *buf)
{
	fontSetSize(f,50);
	bitmap *bm  = createBitmapWithInit(46,46,4,getColor(0,255,255,255));//a,b,g,r
	fontPrint(f,bm,10,0,buf,getColor(0,0,0,0),0);	
	show_font_to_lcd(g_pfb_memory,x,y,bm);
}

void show_win()
{
	fontSetSize(f,130);
	bitmap *bm  = createBitmapWithInit(600,100,4,getColor(0,255,204,153));//a,b,g,r
	char buf[]  = "YOU WIN";
	fontPrint(f,bm,0,0,buf,getColor(0,255,255,255),0);	
	show_font_to_lcd(g_pfb_memory,100,100,bm);
}

void show_gameover()
{
	fontSetSize(f,130);
	bitmap *bm  = createBitmapWithInit(600,100,4,getColor(0,255,204,153));//a,b,g,r
	char buf[]  = "GAME OVER";
	fontPrint(f,bm,0,0,buf,getColor(0,255,255,255),0);	
	show_font_to_lcd(g_pfb_memory,100,100,bm);
}

void show2048(int num,int index,int total,int his_total)
{
	static int num_pos[16][2]={{15,15},{130,15},{245,15},{365,15},			//0-3
						{15,130},{130,130},{245,130},{365,130},		//4-7
						{15,245},{130,245},{245,245},{365,245},		//8-11
						{15,360},{130,360},{245,360},{365,360}};		//12-15
	
	//显示分数
	char snum[100];
	sprintf(snum,"%d",total);
	fontSetSize(f,50);
	bitmap *bm  = createBitmapWithInit(200,50,4,getColor(0,195,195,195));//a,b,g,r
	fontPrint(f,bm,10,0,snum,getColor(0,0,0,0),0);	
	show_font_to_lcd(g_pfb_memory,500,199,bm);
	
	//显示最高分
	sprintf(snum,"%d",his_total);
	fontSetSize(f,50);
	bm  = createBitmapWithInit(200,50,4,getColor(0,195,195,195));//a,b,g,r
	fontPrint(f,bm,10,0,snum,getColor(0,0,0,0),0);	
	show_font_to_lcd(g_pfb_memory,500,299,bm);
	
	//显示数组
	int x,y,dis_x,num_size;
	color bm_color,num_color;
	if(num == -1)
		sprintf(snum,".");
	else
		sprintf(snum,"%d",num);
	
	x = num_pos[index][0];
	y = num_pos[index][1];
	
	switch(num){
		case -1:
			num_size = 100;
			dis_x = 0;
			num_color = getColor(0,178,192,204);	//a,b,g,r
			bm_color  = getColor(0,178,192,204);
			break;
		case 2:
			num_size = 100;
			dis_x = 20;
			num_color = getColor(0,104,113,122);	//a,b,g,r
			bm_color  = getColor(0,218,228,238);
			break;
		case 4:
			num_size = 100;
			dis_x = 20;
			num_color = getColor(0,106,111,120);
			bm_color  = getColor(0,200,224,236);
			break;
		case 8:
			num_size = 100;
			dis_x = 20;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,121,177,242);
			break;
		case 16:
			num_size = 90;
			dis_x = 10;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,96,150,245);
			break;
		case 32:
			num_size = 90;
			dis_x = 10;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,95,123,247);
			break;
		case 64:
			num_size = 90;
			dis_x = 10;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,59,93,246);
			break;
		case 128:
			num_size = 70;
			dis_x = 5;
			num_color = getColor(0,104,113,122);
			bm_color  = getColor(0,113,206,237);
			break;	
		case 256:
			num_size = 70;
			dis_x = 5;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,97,204,237);
			break;
		case 512:
			num_size = 70;
			dis_x = 2;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,82,201,233);
			break;
		case 1024:
			num_size = 50;
			dis_x = 0;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,63,197,237);
			break;
		case 2048:
			num_size = 50;
			dis_x = 0;
			num_color = getColor(0,255,255,255);
			bm_color  = getColor(0,58,140,241);
			break;
	}
	
	fontSetSize(f,num_size);
	bm  = createBitmapWithInit(100,100,4,bm_color);//a,b,g,r
	fontPrint(f,bm,dis_x,0,snum,num_color,0);	
	show_font_to_lcd(g_pfb_memory,x,y,bm);
	
	return;
}


void close_font()
{
	fontUnload(f);
}


