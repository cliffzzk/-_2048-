#include "ts.h"

int ts_open()
{
	/* 打开TS设备，以可读可写方式打开 */
	ts_fd = open("/dev/input/event0",O_RDWR);
	if(ts_fd < 0)
	{
		perror("open ts fail");
		return -1;
	}
	return 0;
}

void ts_close()
{
	/* 关闭TS设备 */
	close(ts_fd);		
}

int ts_get_xy(int *s_x,int *s_y,int *e_x,int *e_y){	
	int x,y; 
	// 用于接收触摸屏产生的所有的信息
	struct input_event tsbuf;
	bzero(&tsbuf,sizeof(tsbuf));
		
	//	读取触摸屏产生信号
	while(1){
		read(ts_fd,&tsbuf,sizeof(tsbuf));
		
		if(tsbuf.type == EV_ABS){
			if(tsbuf.code == ABS_X)
				x = tsbuf.value;
			if(tsbuf.code == ABS_Y)
				y = tsbuf.value;
		}
		
		if(tsbuf.type == EV_KEY){
			if(tsbuf.code == BTN_TOUCH && tsbuf.value == 1){//press
				*s_x = x;
				*s_y = y;		
			}
			
			if(tsbuf.code == BTN_TOUCH && tsbuf.value == 0){//relax
				*e_x = x;
				*e_y = y;
				break;		
			}
		}				
	}	
	return 0;
}

/* int img_ts()
{
	int x,y;
	ts_get_xy(&x,&y);
	if(x>0 && x<80 && y>100 && y<380)
		return 1;
	if(x>720 && x<800 && y>100 && y<380)
		return 2;
	if(x>739 && x<775 && y>36 && y<72)
		return 3;
} */

int choose_func()
{
	int s_x,s_y,e_x,e_y;
	ts_get_xy(&s_x,&s_y,&e_x,&e_y);
	if(e_x>130 && e_x<330 && e_y>50 && e_y<230)
		return falbum;
	if(e_x>450 && e_x<630 && e_y>50 && e_y<230)
		return fgame;
	if(e_x>100 && e_x<300 && e_y>270 && e_y<450)
		return fled;
	if(e_x>450 && e_x<630 && e_y>270 && e_y<450)
		return fquit;
	else 
		return 0;
}