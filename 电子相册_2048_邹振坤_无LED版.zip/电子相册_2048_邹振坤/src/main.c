#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include "lcd.h"
#include "ts.h"
#include "pass.h"
#include "font.h"
#include "album.h"
#include "game.h"

int main()
{		
	ts_open();
	lcd_open();
	//��������
	boot_up();
	lcd_draw_bmp(0,0,"/album/home.bmp");

	while(1)
	{
		int mode = choose_func();
		if(mode == falbum){
			album();
			lcd_draw_bmp(0,0,"/album/home.bmp");
			continue;
		}	
		if(mode == fgame)
		{
			game();
			lcd_draw_bmp(0,0,"/album/home.bmp");
			continue;
		}
		if(mode == fled)
			continue;
		if(mode == fquit)
		{
			break;
		}
			
	}
	lcd_clear();
	ts_close();
	lcd_close();
	return 0;
}




