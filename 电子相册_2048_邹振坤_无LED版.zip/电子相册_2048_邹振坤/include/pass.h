#ifndef __PASS_H__
#define __PASS_H__

#include <stdio.h>
#include "lcd.h"
#include "ts.h"
#include <unistd.h>

int get_pass();
int inspect_pass(int pass[],int my_pass[]);
void show_pass(int bit, int num);
int boot_up();

#endif
