#ifndef __TS_H__
#define __TS_H__

#include <linux/input.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <strings.h>
#include <stdio.h>	
#include <stdbool.h>

int ts_fd;

#define fgame 1
#define fled 2
#define fquit 3
#define falbum 4
//#define botton 4

int ts_open();
void ts_close();
int ts_get_xy(int *s_x,int *s_y,int *e_x,int *e_y );
int choose_func();
//int img_ts();

#endif
