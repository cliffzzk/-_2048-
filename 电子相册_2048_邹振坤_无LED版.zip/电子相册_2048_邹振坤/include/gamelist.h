#ifndef __GAMELIST_H__
#define __GAMELIST_H__

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

#include "kernel_list.h"

typedef struct game{
	int total;
	int his_total;
	int is_last;	//为1时,表示此数组是上次退出时的游戏数据
	int arr[16];
}ST_GAME,*ST_GAME_P;

typedef struct game_node{
	ST_GAME data;
	struct list_head list;
}GAME_NODE,*GAME_NODE_P;

static GAME_NODE_P head_game;
static struct list_head *head_pos_g = NULL; //用于返回到头结点的位置

//头结点初始化
GAME_NODE_P init_gamelist(void);
//判空
bool is_gamelist_empty(GAME_NODE_P head);
//返回链表的头结点的位置
GAME_NODE_P move_gamelist_head(void);
// 清空链表
void clear_gamelist(GAME_NODE_P *head);
//新建节点
GAME_NODE_P new_game_node(ST_GAME_P data);
//把数据插入链表
GAME_NODE_P add_game_node(int total,int his_total,int is_last,int *arr);
//保存数据
void save_gamelist(GAME_NODE_P head);
//读取数据
bool read_gamelist(GAME_NODE_P *head);
//查找is_last为1的节点，把头结点移动到这个节点
bool show_last(GAME_NODE_P *head);


#endif