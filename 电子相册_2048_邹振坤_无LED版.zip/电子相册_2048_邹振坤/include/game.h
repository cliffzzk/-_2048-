#ifndef __GAME_H__
#define __GAME_H__

#include <sys/types.h>
#include <time.h>
#include "gamelist.h"
#include "ts.h"
#include "lcd.h"

#define SIZE    16

static int arr[SIZE] = {0};
static int is_move = 0;       // 这个标志是判断是否有移动过没有
static int is_merge = 0;      // 这个标志是判断是否有合并过没有
static int max;               // 当前最大数字
static int total=0;             // 统计总分数
static int his_total=0;         // 统计历史最高分
 
void game(); 
//显示一维数组的数据和得分，并判断游戏是否结束,判断历史最高分
void print_game(void);
//初始化数组，产生两个不同的随机数，从0-15产生，对应数组下标，然后把该下标数组的值设置为2
void init_2048(void);
//判断是否不能移动并且合并，就是game over了
int is_dead();
//  这个函数返回当前最大的数字,判断是否胜利 
int max_num(void);
//在数组的随机一个空位生成一个2，1/5的几率产生4
void rand_num(void);
//数组完成一次移动:循环次数，当前下标，方向
void move_go(int loop_count, int current_i, int direction);
//计算向上移动的循环次数和设定方向
void move_up(void);
void move_down(void);
void move_right(void);
void move_left(void);
//合并函数，只负责一次合并，把接收当前数字下标，把它上或者下或者左或者右的格子合并一个
void merge(int current_i, int direction);
//第一步移动清除空白，第二步合并，第三步移动清除空白，完成一次移动合并操作
void move_up_pre(void);
void move_down_pre(void);
void move_right_pre(void);
void move_left_pre(void);
//把移动后的数据插入链表
void update_data();
//撤回/重做
void redo_revoke(struct list_head *pos);
//恢复游戏数据
bool show_last_data();

#endif