#ifndef __COMMON_H__
#define __COMMON_H__
struct dir_size
{
	int GB;
	int MB;
	int KB;
	int B;
}size;

#endif