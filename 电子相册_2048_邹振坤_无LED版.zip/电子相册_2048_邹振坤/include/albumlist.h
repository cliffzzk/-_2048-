#ifndef __ALBUMLIST_H__
#define __ALBUMLIST_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <dirent.h>
#include <unistd.h>
#include "kernel_list.h"

typedef struct pic{
	char path[500];
	char name[256];
	bool last;
}PIC,*PIC_P;

typedef struct pic_node{
	PIC pic;
	struct list_head list;
}PIC_NODE,*PIC_NODE_P;

static PIC_NODE_P head;
static struct list_head *head_pos = NULL; //用于返回到头结点的位置

//查看照片是否存在
bool is_exist(PIC_NODE_P head,char *name);
//查找上次最后打开的照片
PIC_NODE_P is_last(PIC_NODE_P *head);
//判空
bool is_empty(PIC_NODE_P head);
//头结点初始化
PIC_NODE_P init_list(void);
//返回链表的头结点的位置
PIC_NODE_P move_head(void);
//新建节点
PIC_NODE_P new_node(PIC_P pic);
//遍历
void show(PIC_NODE_P head);
// 销毁链表释放内存(包括头结点)
void quit_album(PIC_NODE_P *head);
//保存数据
void save(PIC_NODE_P head);
//读取数据
bool read_data(PIC_NODE_P *head);

#endif